package com.javastack.spring.DojosNinjas2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DojosNinjas22ApplicationTests {

	@Test
	void contextLoads() {
	}

}

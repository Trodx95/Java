package com.javastack.spring.FruityLoops;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FruityLoops2Application {

	public static void main(String[] args) {
		SpringApplication.run(FruityLoops2Application.class, args);
	}

}

package com.javastack.spring.OmikujiForm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmikujiForm2ApplicationTests {

	@Test
	void contextLoads() {
	}

}

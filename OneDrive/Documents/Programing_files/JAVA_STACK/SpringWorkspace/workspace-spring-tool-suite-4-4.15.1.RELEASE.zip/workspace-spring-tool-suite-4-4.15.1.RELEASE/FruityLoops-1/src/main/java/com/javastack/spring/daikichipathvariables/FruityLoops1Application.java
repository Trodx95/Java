package com.javastack.spring.daikichipathvariables;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FruityLoops1Application {

	public static void main(String[] args) {
		SpringApplication.run(FruityLoops1Application.class, args);
	}

}

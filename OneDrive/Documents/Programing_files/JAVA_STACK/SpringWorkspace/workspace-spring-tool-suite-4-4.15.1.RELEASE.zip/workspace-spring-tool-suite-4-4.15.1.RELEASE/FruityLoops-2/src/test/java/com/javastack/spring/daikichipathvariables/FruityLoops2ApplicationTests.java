package com.javastack.spring.daikichipathvariables;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FruityLoops2ApplicationTests {

	@Test
	void contextLoads() {
	}

}

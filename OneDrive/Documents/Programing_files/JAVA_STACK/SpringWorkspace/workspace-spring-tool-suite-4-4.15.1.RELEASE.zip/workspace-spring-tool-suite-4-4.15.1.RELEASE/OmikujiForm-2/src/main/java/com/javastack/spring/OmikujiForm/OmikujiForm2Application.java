package com.javastack.spring.OmikujiForm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OmikujiForm2Application {

	public static void main(String[] args) {
		SpringApplication.run(OmikujiForm2Application.class, args);
	}

}

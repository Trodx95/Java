package com.javastack.spring.SaveTravels;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OmikujiTake2Application {

	public static void main(String[] args) {
		SpringApplication.run(OmikujiTake2Application.class, args);
	}

}

package com.javastack.spring.SaveTravels;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaveTravels1Application {

	public static void main(String[] args) {
		SpringApplication.run(SaveTravels1Application.class, args);
	}

}

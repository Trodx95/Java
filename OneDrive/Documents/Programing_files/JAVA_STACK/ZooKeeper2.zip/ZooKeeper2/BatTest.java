public class BatTest {

    public static void main(String[] args){
        Bat a = new Bat(300);
    a.displayEnergy();
    a.attackTown();
    a.attackTown();
    a.attackTown();
    a.eatHuman();
    a.eatHuman();
    a.Fly();
    a.Fly();
    a.displayEnergy();

    
    }
}